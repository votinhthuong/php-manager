<?php

    if (defined('LOADED') == false)
        exit;

    define('DESKTOP_CODE_IS_LOGIN',         1);
    define('DESKTOP_CODE_IS_NOT_LOGIN',     2);
    define('DEKSTOP_CODE_IS_LOGIN_ALREADY', 4);
