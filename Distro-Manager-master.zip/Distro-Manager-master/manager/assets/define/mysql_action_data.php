<?php

    if (defined('LOADED') == false)
        exit;

    define('MYSQL_ACTION_DATA_DELETE_MULTI', 'delete_multi');
