<?php

    return [
        'alert' => [
            'not_permission_access_feature' => 'Bạn không có quyền truy cập vào tính năng đó'
        ]
    ];

?>