<?php

    return [
        'title_page' => 'Thông tin hệ thống'
    ];
