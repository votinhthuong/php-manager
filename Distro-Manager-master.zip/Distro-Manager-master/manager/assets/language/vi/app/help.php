<?php

    if (defined('LOADED') == false)
        exit;

    return [
        'title_page' => 'Trợ giúp'
    ];

?>